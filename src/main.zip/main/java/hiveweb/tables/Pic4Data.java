package hiveweb.tables;

public class Pic4Data {
    private String year;
    private String rcity;
    private String revenue;
    private String cavgrevenue;


    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getRcity() {
        return rcity;
    }

    public void setRcity(String rcity) {
        this.rcity = rcity;
    }

    public String getRevenue() {
        return revenue;
    }

    public void setRevenue(String revenue) {
        this.revenue = revenue;
    }

    public String getCavgrevenue() {
        return cavgrevenue;
    }

    public void setCavgrevenue(String cavgrevenue) {
        this.cavgrevenue = cavgrevenue;
    }
}
