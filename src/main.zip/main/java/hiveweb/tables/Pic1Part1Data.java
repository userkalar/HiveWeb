package hiveweb.tables;

public class Pic1Part1Data {
    private String year;
    private String indicator;
    private String unit;
    private String accumulate;
    private String agrowth;

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getIndicator() {
        return indicator;
    }

    public void setIndicator(String indicator) {
        this.indicator = indicator;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getAccumulate() {
        return accumulate;
    }

    public void setAccumulate(String accumulate) {
        this.accumulate = accumulate;
    }

    public String getAgrowth() {
        return agrowth;
    }

    public void setAgrowth(String agrowth) {
        this.agrowth = agrowth;
    }
}
