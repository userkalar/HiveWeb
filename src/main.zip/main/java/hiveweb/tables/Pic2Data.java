package hiveweb.tables;

public class Pic2Data {
    private String year;
    private String unit;
    private String volume;
    private String vgrowth;
    private String revenue;
    private String rgrowth;
    private String avgvolume;
    private String avgrevenue;

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getVolume() {
        return volume;
    }

    public void setVolume(String volume) {
        this.volume = volume;
    }

    public String getVgrowth() {
        return vgrowth;
    }

    public void setVgrowth(String vgrowth) {
        this.vgrowth = vgrowth;
    }

    public String getRevenue() {
        return revenue;
    }

    public void setRevenue(String revenue) {
        this.revenue = revenue;
    }

    public String getRgrowth() {
        return rgrowth;
    }

    public void setRgrowth(String rgrowth) {
        this.rgrowth = rgrowth;
    }

    public String getAvgvolume() {
        return avgvolume;
    }

    public void setAvgvolume(String avgvolume) {
        this.avgvolume = avgvolume;
    }

    public String getAvgrevenue() {
        return avgrevenue;
    }

    public void setAvgrevenue(String avgrevenue) {
        this.avgrevenue = avgrevenue;
    }
}
