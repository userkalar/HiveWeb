package hiveweb.tables;

public class Pic5Data {
    private String year;
    private String vcity;
    private String volume;
    private String cavgvolume;

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getVcity() {
        return vcity;
    }

    public void setVcity(String vcity) {
        this.vcity = vcity;
    }

    public String getVolume() {
        return volume;
    }

    public void setVolume(String volume) {
        this.volume = volume;
    }

    public String getCavgvolume() {
        return cavgvolume;
    }

    public void setCavgvolume(String cavgvolume) {
        this.cavgvolume = cavgvolume;
    }
}
